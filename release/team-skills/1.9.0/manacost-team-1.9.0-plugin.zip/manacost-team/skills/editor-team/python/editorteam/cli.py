"""Единый CLI: `editor-team`.

Обёртка над анализаторами скилла — старые скрипты продолжают работать
как раньше, здесь добавлены профили, JSON и единый exit code.

Флаги объявляются только те, что действительно что-то делают.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from editorteam import corpus as Corpus
from editorteam import profiles as P
from editorteam import ru_audit as RuAudit
from editorteam import rules
from editorteam import spell_hints as SpellHints
from editorteam import typography as Typography
from editorteam.bg_import import import_directory, import_guides_directory
from editorteam.corpus_learning import CorpusError, CorpusStore
from editorteam.finding import Finding, Report, exit_code
from editorteam.wordpress import ExportError, export_html_file, load_catalog

ROOT = Path(__file__).resolve().parents[2]
CORPUS_COLLECTIONS = ["main", "bg", "archive"]
REPO_SKILL_SCRIPTS = ROOT / ".claude" / "skills" / "hs-edit" / "scripts"
SKILL_SCRIPTS = REPO_SKILL_SCRIPTS if REPO_SKILL_SCRIPTS.exists() else ROOT / "scripts"


def _scripts():
    """Подключить анализаторы скилла, не ломая их расположение."""
    if str(SKILL_SCRIPTS) not in sys.path:
        sys.path.insert(0, str(SKILL_SCRIPTS))
    import common as C

    return C


def _read(path: Path) -> str:
    if not path.exists():
        print(f"нет файла: {path}", file=sys.stderr)
        raise SystemExit(2)
    # newline="" не нужен: CRLF схлопывается в LF единообразно на всех системах
    return path.read_text(encoding="utf-8")


def _line_of(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def audit(args) -> int:
    if getattr(args, "task_context", None):
        if args.deep or args.strict:
            raise ValueError("--deep/--strict are not supported with --task-context yet")
        from editorteam.server import analyze
        from editorteam.task_context import adapt_editor_request

        selected = adapt_editor_request(
            {
                "task_context": json.loads(_read(Path(args.task_context))),
                "profile": args.profile,
            }
        )
        result = analyze(
            _read(Path(args.file)),
            selected["game"],
            selected["profile"],
            args.mode,
            args.evidence_requested,
        )
        report = Report(document=str(args.file), profile=result["profile"])
        result["document"] = str(args.file)
        report.findings = [Finding(**item) for item in result["findings"]]
        report.metrics, report.notes, report.skipped = (
            result["metrics"],
            result["notes"],
            result["analyzers_skipped"],
        )
        if args.format == "json":
            print(
                json.dumps(
                    {**result, "task_context": selected["task_context"]},
                    ensure_ascii=False,
                    indent=2,
                )
            )
        else:
            _emit(report, args)
        return exit_code(report, args.fail_on)
    C = _scripts()
    text = _read(Path(args.file))
    profile_name = args.profile
    confidence = None
    if not profile_name:
        profile_name, confidence = P.detect(text)
    profile = P.load(profile_name)

    report = Report(document=str(args.file), profile=profile.id)
    if confidence is not None:
        report.notes.append(
            f"профиль определён автоматически: {profile.id} (уверенность {confidence}); "
            f"указать явно — --profile"
        )
    words = len(text.split())
    if words < profile.min_words:
        report.notes.append(
            f"текст короче минимума профиля ({words} из {profile.min_words} слов) — "
            f"частотные метрики шумят, категоричных выводов не будет"
        )

    # маркеры шаблона
    if profile.enabled("markers"):
        markers = C.sibling("markers")
        for hit in markers.scan(text, markers.load_patterns()):
            sev = {"remove": "likely", "rewrite": "likely", "review": "review"}[hit["action"]]
            report.add(
                Finding(
                    id=f"markers.{hit['id']}",
                    analyzer="markers",
                    category=hit["action"],
                    severity=sev,
                    confidence=0.6 if sev == "review" else 0.8,
                    message=hit["name"],
                    evidence=hit["text"],
                    suggestion=hit["fix"],
                    line=hit["line"],
                    profile=profile.id,
                )
            )
    else:
        report.skipped.append("markers")

    # Evidence управляет смыслом совета, но в GUIDE не просачивается
    # в читательский текст как пересказ исследования.
    guide_voice = C.sibling("guide_voice")
    for hit in guide_voice.scan(text, args.mode, args.evidence_requested):
        report.add(
            Finding(
                id=f"guide_voice.{hit['id']}",
                analyzer="guide_voice",
                category="editorial-mode",
                severity=hit["severity"],
                confidence=0.9,
                message="research-report narration в режиме GUIDE",
                evidence=hit["evidence"],
                suggestion=hit["suggestion"],
                line=hit["line"],
                profile=profile.id,
            )
        )

    # Понятность публичной статьи: роли игровых терминов, нагрузка абзацев
    # и наличие тезиса. Для старых профилей анализатор выключен, поэтому их
    # JSON и пороги остаются совместимыми.
    if profile.enabled("clarity"):
        clarity = C.sibling("clarity")
        clarity_findings, clarity_metrics = clarity.analyze(text, profile.id)
        for hit in clarity_findings:
            report.add(
                Finding(
                    id=hit["id"],
                    analyzer="clarity",
                    category=hit["category"],
                    severity=hit["severity"],
                    confidence=hit.get("confidence", 0.7),
                    message=hit["message"],
                    evidence=hit.get("evidence", ""),
                    suggestion=hit.get("suggestion", ""),
                    line=hit.get("line"),
                    profile=profile.id,
                    meta=hit.get("meta", {}),
                )
            )
        report.metrics.update({f"clarity_{key}": value for key, value in clarity_metrics.items()})

    # названия карт — точная сверка со справочником
    if profile.enabled("cards"):
        cards = C.sibling("cards")
        cards.ensure_pymorphy()
        db = C.card_db()
        idx = cards.Index(db["карты"], C.morph())
        for (was, off), n in cards.check_apostrophes(text, idx).items():
            report.add(
                Finding(
                    id="cards.apostrophe",
                    analyzer="cards",
                    category="localization",
                    severity="error",
                    message="апостроф в названии карты",
                    evidence=was,
                    suggestion=off,
                    profile=profile.id,
                    meta={"count": n},
                )
            )
        for (was, off), n in cards.check_dashes(text, db["карты"]).items():
            report.add(
                Finding(
                    id="cards.dash",
                    analyzer="cards",
                    category="localization",
                    severity="error",
                    message="тире в названии карты",
                    evidence=was,
                    suggestion=off,
                    profile=profile.id,
                    meta={"count": n},
                )
            )
    else:
        report.skipped.append("cards")

    # согласованность
    if profile.enabled("consistency"):
        cons = C.sibling("consistency")
        for label, forms in cons.check_variants(C.mask_protected(text), strict=args.strict):
            report.add(
                Finding(
                    id="consistency.variants",
                    analyzer="consistency",
                    category="spelling",
                    severity="likely",
                    confidence=0.85,
                    message=f"разнобой: {label}",
                    evidence=", ".join(f"{f} ×{c}" for f, c in forms[:4]),
                    suggestion="выбрать одно написание",
                    profile=profile.id,
                )
            )
        for card, stance in cons.check_advice(text).items():
            report.add(
                Finding(
                    id="consistency.advice",
                    analyzer="consistency",
                    category="advice",
                    severity="review",
                    confidence=0.4,
                    message=f"советы по карте «{card}» расходятся",
                    evidence=stance["оставлять"][0][:90],
                    suggestion="проверить: возможно, речь о разных матч-апах",
                    profile=profile.id,
                )
            )
    else:
        report.skipped.append("consistency")

    # структура — по профилю
    if profile.enabled("structure"):
        st = C.sibling("structure")
        heads = [h.lower() for _, h in st.headings(text)]
        for section in profile.required_sections:
            if not any(h in section.variants for h in heads):
                report.add(
                    Finding(
                        id=f"structure.missing.{section.id}",
                        analyzer="structure",
                        category="structure",
                        severity="likely",
                        confidence=0.7,
                        message=f"нет обязательного раздела «{section.title}»",
                        suggestion="; ".join(section.variants[:3]),
                        profile=profile.id,
                        meta={"corpus_share": section.corpus_share},
                    )
                )
        if profile.require_classes:
            found = st.find_blocks(st.headings(text))
            mu = st.check_matchups(text, st.headings(text), found)
            if mu and mu[1]:
                report.add(
                    Finding(
                        id="structure.matchups",
                        analyzer="structure",
                        category="coverage",
                        severity="review",
                        confidence=0.8,
                        message=f"матч-апы без {len(mu[1])} классов",
                        evidence=", ".join(mu[1]),
                        profile=profile.id,
                    )
                )
        # --deep: порядок, тонкие разделы, полотна и зачин. Не по умолчанию,
        # чтобы golden JSON и привычный вывод не менялись.
        if getattr(args, "deep", False):
            deep_findings, deep_metrics = st.analyze(text, profile.id, deep=True)
            for hit in deep_findings:
                if hit["id"].startswith("structure.missing.") or hit["id"] == "structure.matchups":
                    continue
                report.add(
                    Finding(
                        id=hit["id"],
                        analyzer="structure",
                        category="structure",
                        severity=hit["severity"],
                        confidence=hit.get("confidence", 0.7),
                        message=hit["message"],
                        evidence=hit.get("evidence", ""),
                        suggestion=hit.get("suggestion", ""),
                        line=hit.get("line"),
                        profile=profile.id,
                    )
                )
            report.metrics["structure_order_ok"] = deep_metrics.get("order_ok")
            report.metrics["structure_thin"] = deep_metrics.get("thin", [])
    else:
        report.skipped.append("structure")

    # аккуратность: номинализации, серии начал, конкретика. Включается флагом
    # профиля или --deep, чтобы не менять отчёты старых профилей
    if profile.enabled("elegance") and (
        "elegance" in profile.analyzers or getattr(args, "deep", False)
    ):
        elegance = C.sibling("elegance")
        el_metrics = elegance.measure(text)
        for hit in elegance.findings(text, el_metrics):
            report.add(
                Finding(
                    id=hit["id"],
                    analyzer="elegance",
                    category="elegance",
                    severity=hit["severity"],
                    confidence=hit.get("confidence", 0.7),
                    message=hit["message"],
                    evidence=hit.get("evidence", ""),
                    suggestion=hit.get("suggestion", ""),
                    line=hit.get("line"),
                    profile=profile.id,
                    meta=hit.get("meta", {}),
                )
            )
        if el_metrics:
            report.metrics.update(
                {
                    f"elegance_{key}": el_metrics[key]
                    for key in (
                        "nominalization_per_100w",
                        "same_start_runs",
                        "concreteness_per_100w",
                    )
                }
            )

    # измеряемые величины
    if profile.enabled("rhythm"):
        r = C.sibling("rhythm").measure(text)
        if r:
            report.metrics["rhythm_ratio"] = round(r["ratio"], 3)
            report.metrics["sentence_mean"] = round(r["mean"], 1)
    else:
        report.skipped.append("rhythm")

    if profile.enabled("soul"):
        soul = C.sibling("soul")
        s, w = soul.measure(text)
        if s:
            report.metrics["voice_per_1k"] = round(sum(v["per1k"] for v in s.values()), 1)
            report.metrics["voice_norm"] = soul.TOTAL_MED
    else:
        report.skipped.append("soul")

    report.metrics["words"] = words
    _emit(report, args)
    return exit_code(report, args.fail_on)


def cards_cmd(args) -> int:
    args.profile = args.profile or "constructed-guide"
    args.strict = False
    args.deep = False
    args.mode = "GUIDE"
    args.evidence_requested = False
    return audit(args)


def validate_edit(args) -> int:
    from editorteam.server import validate

    before = _read(Path(args.before))
    after = _read(Path(args.after))
    claims_before = json.loads(_read(Path(args.claims_before))) if args.claims_before else None
    claims_after = (
        json.loads(_read(Path(args.claims_after))) if args.claims_after else claims_before
    )
    declared = [x.strip() for x in (args.declared_missing or "").split(",") if x.strip()]
    selected = None
    if getattr(args, "task_context", None):
        from editorteam.task_context import adapt_editor_request

        selected = adapt_editor_request(
            {
                "task_context": json.loads(_read(Path(args.task_context))),
                "game": args.game,
                "profile": args.profile,
                "current_patch": args.current_patch,
            }
        )
        args.game, args.profile, args.current_patch = (
            selected["game"],
            selected["profile"],
            selected["current_patch"],
        )
    result = validate(
        before,
        after,
        args.game or "hearthstone",
        args.profile,
        mode=args.mode,
        depth=args.depth,
        declared_missing=declared,
        claims_before=claims_before,
        claims_after=claims_after,
        current_meta_epoch=args.current_meta_epoch,
        current_patch=args.current_patch,
        author=args.author,
        meaning=args.meaning,
    )
    if selected:
        result["task_context"] = selected["task_context"]
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if result["accepted"] else "REJECTED")
        for item in result["violations"]:
            print(f"  [{item['kind']}] {item['message']}")
        for item in result.get("warnings", []):
            print(f"  [REVIEW:{item['kind']}] {item['message']}")
        if result.get("edit_depth") == "переплавка":
            m = result["metrics"]
            print("\n  ПЕРЕПЛАВКА")
            for key in (
                "rewrite_voice_total",
                "rewrite_rhythm_ratio",
                "rewrite_markers_per_10k",
                "rewrite_sections_missing",
                "rewrite_sections_declared_missing",
                "coverage_pct",
                "coverage_cards_covered",
                "coverage_cards_total",
            ):
                if key in m:
                    print(f"    {key:<34} {m[key]}")
    return 0 if result["accepted"] else 1


CHECK_HINTS = {
    "protected_lost": "вернуть пропавшие числа, коды и защищённые слова дословно",
    "CLAIM_COVERAGE_LOST": "вернуть карту, совет или отрицание из исходника",
    "voice_below_norm": "проверить авторскую функцию фрагмента; квоты сигналов нет",
    "rhythm_below_norm": "прочитать в контексте; снижение счётчика не требует правки",
    "markers_remove_present": "вырезать шаблонные фразы без замены",
    "markers_above_norm": "переписать от смысла: назвать факт вместо рамки",
    "structure_missing": "добавить раздел из материала исходника или объявить его отсутствующим",
    "term_replace": "заменить по словарю автора; ранги по локализации",
    "form_tables": "оставить одну таблицу, остальное прозой",
    "form_codes": "коды только для рекомендуемых сборок",
    "form_grade_labels": "сказать словами, где колода стоит",
    "form_fact_repeated": "назвать цифру один раз, дальше ссылаться на вывод",
    "lexicon_gap": "проверить значение в контексте; отсутствие в корпусе не требует замены",
    "CERTAINTY_DRIFT": "не усиливать совет: «можно» не становится «обязательно»",
    "FACTUAL_SEMANTIC_DRIFT": "вернуть отрицание и числа исходника",
    "EVIDENCE_NARRATION_LEAK": "убрать пересказ исследования, оставить прямой совет",
    "text_shrunk": "проверить каждое удаление",
    "voice_flattened": "проверить сохранность авторской мысли; не добавлять обороты ради счётчика",
    "rhythm_flattened": "проверить читаемость; не откатывать правку только ради метрики",
}


def check_cmd(args) -> int:
    """Один вердикт на текст: затвор, покрытие, словарь и форма вместе.

    С исходником — полный затвор переплавки (или указанной глубины); без
    исходника — только абсолютные нормы автора.
    """
    from editorteam.server import validate

    C = _scripts()
    after = _read(Path(args.file))
    profile = args.profile or "constructed-guide"
    declared = [x.strip() for x in (args.declared_missing or "").split(",") if x.strip()]
    if args.source:
        result = validate(
            _read(Path(args.source)),
            after,
            args.game,
            profile,
            mode=args.mode,
            depth=args.depth,
            declared_missing=declared,
            author=args.author,
            meaning=args.meaning,
        )
    else:
        gate = C.sibling("rewrite_gate")
        v, w, m = gate.analyze(
            after,
            norms=gate.norms_for(args.game),
            profile=profile,
            declared_missing=declared,
            game=args.game,
            author=args.author,
            meaning=args.meaning,
        )
        result = {
            "accepted": not v,
            "violations": v,
            "warnings": w,
            "metrics": m,
            "edit_depth": args.depth,
            "profile": profile,
        }
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["accepted"] else 1
    print("PASS" if result["accepted"] else "REJECTED")
    seen = set()
    for item in result["violations"]:
        hint = item.get("suggestion") or CHECK_HINTS.get(item["kind"], "")
        print(f"  [{item['kind']}] {item['message']}")
        if hint and item["kind"] not in seen:
            print(f"      → {hint}")
            seen.add(item["kind"])
    for item in result.get("warnings", []):
        print(f"  [REVIEW:{item['kind']}] {item['message']}")
    m = result["metrics"]
    print("\n  ИЗМЕРЕНО (по прозе)")
    for key in (
        "rewrite_words",
        "words",
        "rewrite_voice_total",
        "voice_total",
        "rewrite_rhythm_ratio",
        "rhythm_ratio",
        "rewrite_markers_per_10k",
        "markers_per_10k",
        "coverage_pct",
        "rewrite_sections_missing",
        "sections_missing",
        "rewrite_terminology_hits",
        "terminology_hits",
        "rewrite_form",
        "form",
    ):
        if key in m:
            print(f"    {key.replace('rewrite_', ''):<20} {m[key]}")
    return 0 if result["accepted"] else 1


def learn_cmd(args) -> int:
    """Журнал правок: из диффа «до → после» или одной строкой."""
    from editorteam import corrections as CR

    context = {
        key: getattr(args, key, "") or ""
        for key in ("author", "game", "genre", "meaning", "model_proposal")
    }
    context["scope"] = getattr(args, "scope", "local")

    if args.learn_cmd == "list":
        items = CR.load()
        if args.format == "json":
            print(json.dumps([c.to_dict() for c in items], ensure_ascii=False, indent=2))
        else:
            for c in items:
                why = f" — {c.reason}" if c.reason else ""
                print(f"  [{c.kind}] {c.was} → {c.became}{why}")
            print(f"\n  правок в журнале: {len(items)}")
        return 0
    if args.learn_cmd == "add":
        try:
            item = CR.add(
                args.was,
                args.became,
                kind=args.kind,
                reason=args.reason or "",
                source=args.source or "",
                context=args.context or "",
                operation=args.operation,
                **context,
            )
        except CR.CorrectionsError as exc:
            print(str(exc), file=sys.stderr)
            return 2
        print(f"записано: [{item.kind}] {item.was} → {item.became}")
        return 0
    before, after = _read(Path(args.before)), _read(Path(args.after))
    found = CR.proposals(before, after)
    written = 0
    if not args.dry_run:
        for item in found:
            CR.add(
                item["was"],
                item["became"],
                kind=item["kind"],
                reason=args.reason or "",
                context=item["context"],
                operation=item["operation"],
                source=args.source or "",
                **context,
            )
            written += 1
    if args.format == "json":
        print(json.dumps({"proposals": found, "written": written}, ensure_ascii=False, indent=2))
        return 0
    if not found:
        print("замен, похожих на правило, в диффе нет")
    for item in found:
        print(f"  [{item['kind']}] {item['was']} → {item['became']}    ({item['context']})")
    if written:
        print(f"\n  записано в журнал: {written}; допишите reason в config/corrections.yaml")
    return 0


def claims_cmd(args) -> int:
    """Инвентаризация утверждений источника и покрытие после переплавки."""
    C = _scripts()
    claims = C.sibling("claims")
    profile = args.profile or "constructed-guide"
    source = claims.extract(_read(Path(args.source)), profile=profile)
    if not args.after:
        if args.format == "json":
            print(json.dumps(source, ensure_ascii=False, indent=2))
        else:
            print(
                f"\n{args.source}: {source['words']} слов, архетип {source['archetype'] or '—'}; "
                f"карт {len(source['cards'])}, советов {len(source['stances'])}, "
                f"отрицаний {len(source['negations'])}, чисел {len(source['numbers'])}, "
                f"классов {len(source['classes'])}"
            )
            for card in source["cards"]:
                print(f"  карта  {card['name']} ×{card['mentions']}  стр.{card['line']}")
            for neg in source["negations"]:
                print(
                    f"  «не»   [{neg['anchor_kind']}/{neg.get('type', 'fact')}] "
                    f"{neg['anchor']}: {neg['sentence'][:90]}"
                )
        return 0
    declared = [x.strip() for x in (args.declared_missing or "").split(",") if x.strip()]
    violations, warnings, metrics = claims.coverage(
        source, _read(Path(args.after)), declared_missing=declared
    )
    result = {
        "accepted": not violations,
        "violations": violations,
        "warnings": warnings,
        "metrics": metrics,
    }
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if not violations else "REJECTED")
        for item in violations:
            print(f"  [{item['kind']}:{item['field']}] {item['message']}")
        for item in warnings:
            print(f"  [REVIEW:{item['field']}] {item['message']}")
        print(f"\n  покрытие {metrics['coverage_pct']}%")
    return 0 if not violations else 1


def outline_validate(args) -> int:
    """План переплавки против скелета профиля и исходника."""
    from editorteam.server import validate_outline

    raw = _read(Path(args.outline))
    try:
        outline = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"план не JSON: {exc}", file=sys.stderr)
        return 2
    source = _read(Path(args.source)) if args.source else ""
    result = validate_outline(outline, source, args.game, args.profile)
    if args.format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if result["ok"] else "REJECTED")
        for item in result["violations"]:
            print(f"  [{item['kind']}] {item['message']}")
        for item in result["warnings"]:
            print(f"  [REVIEW] {item['message']}")
    return 0 if result["ok"] else 1


def corpus_validate(args) -> int:
    C = _scripts()
    report = Report(document=str(C.CORPUS), profile="corpus")
    for pr in Corpus.validate():
        report.add(
            Finding(
                id=f"corpus.{pr.kind}",
                analyzer="corpus",
                category="data",
                severity=pr.severity,
                message=pr.message,
                evidence=pr.document,
            )
        )
    st = Corpus.stats()
    report.metrics.update(
        {
            "documents": st["documents"],
            "words": st["words"],
            "unknown_values": st["unknown_values"],
        }
    )
    report.notes.append(f"жанры: {st['by_genre']}; режимы: {st['by_mode']}")
    report.notes.append(
        "значения unknown — не дефект: данных о датах и патчах в исходниках нет, "
        "и выдумывать их нельзя"
    )
    _emit(report, args)
    return exit_code(report, args.fail_on)


def corpus_split(args) -> int:
    """Детерминированное разбиение: калибровка и holdout."""
    parts = Corpus.split()
    if args.format == "json":
        import json as _json

        print(_json.dumps(parts, ensure_ascii=False, indent=2))
        return 0
    print(f"\nкалибровка: {len(parts['calibration'])} документов")
    print(f"holdout:    {len(parts['holdout'])} документов")
    print("  " + ", ".join(parts["holdout"]))
    print("\n  Разбиение по идентификатору, а не случайное: иначе калибровка")
    print("  меняется от запуска к запуску и числа перестают сходиться.")
    return 0


def _corpus_store(collection: str = "main") -> CorpusStore:
    if collection == "bg":
        return CorpusStore(ROOT, corpus_dir_name="corpus-bg", include_legacy=False)
    if collection == "archive":
        return CorpusStore(ROOT, corpus_dir_name="corpus-archive", include_legacy=False)
    return CorpusStore(ROOT)


def _corpus_output(data: dict | list, args) -> int:
    if args.format == "json":
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif isinstance(data, list):
        for item in data:
            print(f"{item['version']:<8} {item['guides']:>4} guides  {item['action']}")
    else:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0


def corpus_add(args) -> int:
    try:
        data = _corpus_store(args.collection).add(
            Path(args.file),
            published_at=args.published_at,
            patch=args.patch,
            author=args.author,
            tags=args.tags,
            source=args.source,
            genre=args.genre,
            approve=args.approve,
            guide_id=args.id,
        )
    except CorpusError as exc:
        payload = {"error": exc.code, "message": str(exc)}
        if args.format == "json":
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    return _corpus_output(data, args)


def corpus_approve(args) -> int:
    return _corpus_mutation(args, "approve", args.guide_id)


def corpus_remove(args) -> int:
    return _corpus_mutation(args, "remove", args.guide_id)


def corpus_reject(args) -> int:
    return _corpus_mutation(args, "reject", args.guide_id)


def corpus_rollback(args) -> int:
    return _corpus_mutation(args, "rollback", args.version)


def _corpus_mutation(args, method: str, value: str) -> int:
    try:
        data = getattr(_corpus_store(args.collection), method)(value)
    except CorpusError as exc:
        if args.format == "json":
            print(json.dumps({"error": exc.code, "message": str(exc)}, ensure_ascii=False))
        else:
            print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    return _corpus_output(data, args)


def corpus_versions(args) -> int:
    return _corpus_output(_corpus_store(args.collection).versions(), args)


def corpus_inspect(args) -> int:
    return _corpus_output(_corpus_store(args.collection).inspect(), args)


def corpus_compare(args) -> int:
    try:
        data = _corpus_store(args.collection).compare(args.before_version, args.after_version)
    except CorpusError as exc:
        print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    return _corpus_output(data, args)


def corpus_import_bg(args) -> int:
    try:
        data = import_directory(Path(args.directory), _corpus_store("bg"))
    except CorpusError as exc:
        if args.format == "json":
            print(json.dumps({"error": exc.code, "message": str(exc)}, ensure_ascii=False))
        else:
            print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    return _corpus_output(data, args)


def corpus_import_guides(args) -> int:
    try:
        data = import_guides_directory(Path(args.directory), _corpus_store("archive"))
    except CorpusError as exc:
        if args.format == "json":
            print(json.dumps({"error": exc.code, "message": str(exc)}, ensure_ascii=False))
        else:
            print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    return _corpus_output(data, args)


def config_validate(args) -> int:
    problems = rules.validate()
    # В дополнение к словарю и типографике проверяем справочник игровых
    # понятий и правила понятности публичных материалов.
    clarity = _scripts().sibling("clarity")
    problems.extend(clarity.validate_config())
    report = Report(document="config/", profile="config")
    for p in problems:
        report.add(
            Finding(
                id="config.conflict",
                analyzer="config",
                category="rules",
                severity="error",
                message=p,
            )
        )
    _emit(report, args)
    return exit_code(report, args.fail_on)


def profiles_cmd(args) -> int:
    for name in P.available():
        p = P.load(name)
        req = ", ".join(s.title for s in p.required_sections) or "—"
        print(f"{p.id:<22} {p.title}")
        print(f"{'':<22} обязательные разделы: {req}")
        print(f"{'':<22} классы в матч-апах: {'да' if p.require_classes else 'нет'}")
    return 0


def wordpress_cmd(args) -> int:
    """Собрать HTML-файл для вставки в WordPress."""
    try:
        catalog = load_catalog(Path(args.catalog)) if args.catalog else ()
        output = export_html_file(
            Path(args.file),
            Path(args.output) if args.output else None,
            catalog=catalog,
            format_override=args.hs_format,
        )
    except (ExportError, OSError) as exc:
        print(f"wordpress: {exc}", file=sys.stderr)
        return 2
    print(output)
    return 0


def typography_cmd(args) -> int:
    """Расставить тире и неразрывные пробелы через Typograf, не меняя слова."""
    path = Path(args.file)
    try:
        text, eol, bom = Typography.read_document(path)
        result = Typography.typograph(text)
        target = Path(args.output) if args.output else path if args.write else None
        if target is not None and (args.output or result.changed):
            Typography.write_document(target, result.text, eol, bom)
    except Typography.ToolUnavailable as exc:
        print(f"типографика не запущена: {exc}", file=sys.stderr)
        return 2
    except (Typography.TypographyError, OSError, UnicodeDecodeError) as exc:
        print(f"типографика отклонена: {exc}", file=sys.stderr)
        return 2
    summary = {
        "lines_changed": result.lines_changed,
        "nbsp_added": result.nbsp_added,
        "dashes_added": result.dashes_added,
        "protected_spans": result.protected,
    }
    if args.format == "json":
        payload = {
            "schema_version": "1.0",
            "document": str(path),
            "tool": {"name": "typograf", "version": result.engine_version},
            "rules": list(result.rules),
            "quotes": rules.typography().get("quotes", {}).get("decision"),
            "changed": result.changed,
            "summary": summary,
            "written": str(target) if target is not None else None,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"типографика: {path}   Typograf {result.engine_version}, правил {len(result.rules)}")
        print(
            f"  изменено строк {result.lines_changed}; неразрывных пробелов +{result.nbsp_added}; "
            f"длинных тире +{result.dashes_added}; защищено участков {result.protected}"
        )
        print("  проверено: слова и символы прежние, изменился только вид пробелов и тире")
        if target is not None:
            print(f"  записано: {target}")
        elif result.changed:
            print("  ничего не записано: --write — в тот же файл, --output — в другой")
    return 1 if args.check and result.changed else 0


def spelling_hints_cmd(args) -> int:
    """Подсказки SAGE об опечатках; текст не меняется, решение за редактором."""
    if not args.file and not args.corpus:
        print("spelling-hints: нужен файл или --corpus", file=sys.stderr)
        return 2
    try:
        provider = SpellHints.SageProvider(
            args.model, device=args.device, allow_download=args.download
        )
        known_word = _scripts().morph().word_is_known
        names = Typography.card_names()
        if args.corpus:
            files = sorted(Path(args.corpus).glob("*.md"))[: args.limit or None]
            summary = SpellHints.evaluate(
                files,
                provider,
                known_word=known_word,
                names=names,
                include_model_only=args.include_model_only,
            )
            _print_corpus_summary(summary, args)
            return 0
        report = SpellHints.analyze(
            _read(Path(args.file)),
            provider,
            known_word=known_word,
            names=names,
            document=str(args.file),
            include_model_only=args.include_model_only,
        )
    except (SpellHints.ProviderUnavailable, Typography.ToolUnavailable) as exc:
        print(f"подсказки орфографии не запущены: {exc}", file=sys.stderr)
        return 2
    _emit(report, args)
    return exit_code(report, args.fail_on)


def _print_corpus_summary(summary: dict, args) -> None:
    if args.format == "json":
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    print(f"корпус: {summary['files']} файлов, {summary['words']} слов")
    print(f"подсказок: {summary['hints']} ({summary['hints_per_1000_words']} на 1000 слов)")
    print("отброшено фильтрами: " + ", ".join(f"{k} {v}" for k, v in summary["dropped"].items()))
    print("частые пары (на вычитанном тексте это ложные срабатывания):")
    for pair, count in summary["top_pairs"]:
        print(f"  {count:>3}  {pair}")


def ru_audit_cmd(args) -> int:
    """Подготовить аудит ru-text и проверить отчёт аудитора; сам аудит делает модель."""
    path = Path(args.file)
    try:
        if args.ru_audit_cmd == "prepare":
            payload = RuAudit.prepare(path, args.mode)
            if args.format == "json":
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(f"SHA-256 текста до аудита: {payload['text_sha256']}")
                print(f"корпус ru-text: {payload['corpus']}\n")
                print(payload["prompt"])
            return 0
        text = path.read_text(encoding="utf-8")
        report = Path(args.report).read_text(encoding="utf-8")
        check = RuAudit.validate_report(
            report,
            text,
            mode=args.mode,
            expected_sha256=args.sha256,
            text_sha256=RuAudit.sha256_of(path),
        )
    except RuAudit.AuditUnavailable as exc:
        print(f"ru-audit: {exc}", file=sys.stderr)
        return 2
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        print(f"ru-audit: {exc}", file=sys.stderr)
        return 2
    if args.strict:
        check.errors.extend(f"строго: {warning}" for warning in check.warnings)
    if args.format == "json":
        print(json.dumps(check.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"аудит ru-text: {args.report}")
        if check.total is not None:
            print(
                f"  итог {check.total} / 10 ({check.label}); по шкалам выходит {check.expected_total}"
            )
        if check.scores:
            print("  шкалы: " + " · ".join(f"{k} {v}" for k, v in check.scores.items()))
        print(
            f"  цитат проверено {check.quotes_checked}, не найдено {len(check.quotes_missing)}, "
            f"примеров правил из корпуса {len(check.quotes_from_catalog)}"
        )
        if check.ad_rules:
            print("  правила AD: " + ", ".join(str(n) for n in check.ad_rules))
        readonly = {
            "verified": "текст не менялся",
            "violated": "текст ИЗМЕНЁН аудитором",
            "unchecked": "неизменность не проверена: нужен --sha256 из prepare",
        }[check.readonly]
        print(f"  {readonly}")
        for error in check.errors:
            print(f"  ошибка: {error}")
        for warning in check.warnings:
            print(f"  предупреждение: {warning}")
        print("  отчёт принят" if check.valid else "  отчёту нельзя доверять: повторите аудит")
    return 0 if check.valid else 1


def _emit(report: Report, args) -> None:
    if args.format == "json":
        print(report.to_json())
        return
    print(f"\n{report.document}   профиль: {report.profile}")
    for note in report.notes:
        print(f"  ! {note}")
    if report.skipped:
        print(f"  пропущены анализаторы: {', '.join(report.skipped)}")
    if not report.findings:
        print("\n  Проверяемых находок нет.")
    for f in sorted(report.findings, key=lambda x: (x.severity, x.line or 0)):
        where = f" стр.{f.line}" if f.line else ""
        print(f"\n  [{f.severity}]{where} {f.message}")
        if f.evidence:
            print(f"      «{f.evidence}»")
        if f.suggestion:
            print(f"      → {f.suggestion}")
    if report.metrics:
        print("\n  ИЗМЕРЕНО")
        for k, v in report.metrics.items():
            print(f"    {k:<18} {v}")
    print("\n  Точная ошибка (error), вероятная (likely) и сигнал редактору (review)")
    print("  различаются: review — приглашение посмотреть, а не дефект.")


def _common() -> argparse.ArgumentParser:
    """Общие флаги. Добавляются и до подкоманды, и после неё: пользователь
    естественно пишет `audit file --format json`, а не наоборот."""
    # default=SUPPRESS обязателен: иначе подпарсер перезапишет значение,
    # заданное до подкоманды, своим None
    c = argparse.ArgumentParser(add_help=False)
    c.add_argument("--format", choices=["text", "json"], default=argparse.SUPPRESS)
    c.add_argument(
        "--fail-on",
        dest="fail_on",
        choices=["error", "likely", "review", "info"],
        default=argparse.SUPPRESS,
        help="при какой серьёзности возвращать код 1",
    )
    return c


def build_parser() -> argparse.ArgumentParser:
    common = _common()
    ap = argparse.ArgumentParser(
        prog="editor-team", parents=[common], description="Редактура материалов по Hearthstone"
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("audit", help="полный разбор материала", parents=[common])
    a.add_argument("file")
    a.add_argument("--task-context", help="JSON общего игрового контекста и стиля Манакоста")
    a.add_argument(
        "--profile", choices=P.available(), help="жанр; без него определяется автоматически"
    )
    a.add_argument("--strict", action="store_true", help="включить слабые сигналы согласованности")
    a.add_argument(
        "--deep",
        action="store_true",
        help="структура глубже присутствия (порядок, тонкие разделы, полотна) и аккуратность",
    )
    a.add_argument("--mode", choices=["GUIDE", "ANALYSIS", "REPORT"], default="GUIDE")
    a.add_argument(
        "--evidence-requested",
        action="store_true",
        help="автор явно попросил показать evidence в тексте",
    )
    a.set_defaults(func=audit)

    wp = sub.add_parser(
        "wordpress", help="собрать WordPress-готовый HTML-фрагмент", parents=[common]
    )
    wp.add_argument("file", help="исходный Markdown или TXT")
    wp.add_argument("--output", help="путь результата; по умолчанию рядом с исходником")
    wp.add_argument(
        "--hs-format",
        choices=["standard", "wild", "arena", "battlegrounds"],
        help="формат Hearthstone; перекрывает начальную директиву «Формат: ...»",
    )
    wp.add_argument(
        "--catalog",
        help="JSON-каталог карточек: name, id и formats; нужен для «Подсветка карт»",
    )
    wp.set_defaults(func=wordpress_cmd)

    ty = sub.add_parser(
        "typography",
        help="тире и неразрывные пробелы через Typograf; слова не меняются",
        parents=[common],
    )
    ty.add_argument("file", help="Markdown или TXT; запускать после проверок и до шорткодов")
    mode = ty.add_mutually_exclusive_group()
    mode.add_argument("--write", action="store_true", help="записать результат в тот же файл")
    mode.add_argument("--output", help="записать результат в другой файл")
    mode.add_argument(
        "--check",
        action="store_true",
        help="ничего не писать; код 1, если типографика не расставлена",
    )
    ty.set_defaults(func=typography_cmd)

    sp = sub.add_parser(
        "spelling-hints",
        help="подсказки SAGE об опечатках: только подсказки, текст не меняется",
        parents=[common],
    )
    sp.add_argument("file", nargs="?", help="Markdown или TXT")
    sp.add_argument("--corpus", help="папка вычитанных .md: сколько подсказок модель даёт на них")
    sp.add_argument("--limit", type=int, help="сколько файлов корпуса взять")
    sp.add_argument("--model", default=SpellHints.DEFAULT_MODEL, help="модель Hugging Face")
    sp.add_argument("--device", choices=["cpu", "cuda"], help="по умолчанию cuda, если есть")
    sp.add_argument(
        "--download", action="store_true", help="разрешить скачать модель с Hugging Face"
    )
    sp.add_argument(
        "--include-model-only",
        action="store_true",
        help="показывать и замену одного известного слова другим (это не опечатка)",
    )
    sp.set_defaults(func=spelling_hints_cmd)

    ra = sub.add_parser(
        "ru-audit",
        help="второй читающий аудитор ru-text: задание аудитору и проверка его отчёта",
        parents=[common],
    )
    ra_sub = ra.add_subparsers(dest="ru_audit_cmd", required=True)
    rap = ra_sub.add_parser("prepare", parents=[common], help="хеш текста и задание аудитору")
    rap.add_argument("file", help="аудируемый текст")
    rap.add_argument("--mode", choices=RuAudit.MODES, default="score")
    rap.set_defaults(func=ru_audit_cmd)
    rav = ra_sub.add_parser("validate", parents=[common], help="проверить отчёт аудитора")
    rav.add_argument("file", help="аудируемый текст")
    rav.add_argument("--report", required=True, help="отчёт аудитора, Markdown")
    rav.add_argument("--mode", choices=RuAudit.MODES, default="score")
    rav.add_argument(
        "--sha256", help="хеш текста из prepare: проверяет, что аудитор ничего не менял"
    )
    rav.add_argument("--strict", action="store_true", help="предупреждения считать ошибками")
    rav.set_defaults(func=ru_audit_cmd)

    ve = sub.add_parser("validate-edit", help="затвор смысла и confidence", parents=[common])
    ve.add_argument("before")
    ve.add_argument("after")
    ve.add_argument("--game", help="игра; legacy default: hearthstone")
    ve.add_argument("--author", default="manacost")
    ve.add_argument("--meaning", default="")
    ve.add_argument("--task-context", help="JSON общего игрового контекста и стиля Манакоста")
    ve.add_argument("--profile", choices=P.available())
    ve.add_argument("--mode", choices=["GUIDE", "ANALYSIS", "REPORT"], default="GUIDE")
    ve.add_argument(
        "--depth",
        choices=["лёгкая", "обычная", "глубокая", "переплавка"],
        default="обычная",
        help="глубина правки; «переплавка» судит по норме автора, а не по исходнику",
    )
    ve.add_argument(
        "--declared-missing",
        dest="declared_missing",
        default="",
        help="id разделов, для которых в исходнике нет материала, через запятую",
    )
    ve.add_argument("--claims-before")
    ve.add_argument("--claims-after")
    ve.add_argument("--current-meta-epoch")
    ve.add_argument("--current-patch")
    ve.set_defaults(func=validate_edit)

    ck = sub.add_parser(
        "check", help="один вердикт: затвор, покрытие, словарь, форма", parents=[common]
    )
    ck.add_argument("file", help="проверяемый текст")
    ck.add_argument("--source", help="исходник: включает покрытие утверждений и защиту фактов")
    ck.add_argument("--profile", choices=P.available())
    ck.add_argument("--game", default="hearthstone")
    ck.add_argument("--author", default="manacost")
    ck.add_argument("--meaning", default="")
    ck.add_argument(
        "--depth", choices=["лёгкая", "обычная", "глубокая", "переплавка"], default="переплавка"
    )
    ck.add_argument("--mode", choices=["GUIDE", "ANALYSIS", "REPORT"], default="GUIDE")
    ck.add_argument("--declared-missing", dest="declared_missing", default="")
    ck.set_defaults(func=check_cmd)

    ln = sub.add_parser(
        "learn", help="журнал правок автора: было → стало → почему", parents=[common]
    )
    ln_sub = ln.add_subparsers(dest="learn_cmd", required=True)
    ld = ln_sub.add_parser("diff", parents=[common], help="вынуть замены из диффа до → после")
    ld.add_argument("before")
    ld.add_argument("after")
    ld.add_argument("--reason", default="")
    ld.add_argument("--source", default="")
    ld.add_argument(
        "--dry-run", dest="dry_run", action="store_true", help="показать, не записывать"
    )
    ld.set_defaults(func=learn_cmd)
    la = ln_sub.add_parser("add", parents=[common], help="записать одну правку")
    la.add_argument("was")
    la.add_argument("became")
    la.add_argument("--kind", choices=["term", "phrase", "structure", "fact"], default="phrase")
    la.add_argument("--reason", default="")
    la.add_argument("--source", default="")
    la.add_argument("--context", default="")
    la.add_argument("--operation", choices=["replace", "insert", "delete"], default="replace")
    for learning_parser in (ld, la):
        learning_parser.add_argument("--author", default="")
        learning_parser.add_argument("--game", default="")
        learning_parser.add_argument("--genre", default="")
        learning_parser.add_argument("--meaning", default="")
        learning_parser.add_argument(
            "--scope",
            choices=["language_norm", "author_global", "local", "fact", "structure"],
            default="local",
        )
        learning_parser.add_argument("--model-proposal", default="")
    la.set_defaults(func=learn_cmd)
    ll = ln_sub.add_parser("list", parents=[common], help="показать журнал")
    ll.set_defaults(func=learn_cmd)

    cl = sub.add_parser("claims", help="утверждения источника и их покрытие", parents=[common])
    cl.add_argument("source")
    cl.add_argument("--after", dest="after", help="переплавленный текст")
    cl.add_argument("--profile", choices=P.available())
    cl.add_argument("--declared-missing", dest="declared_missing", default="")
    cl.set_defaults(func=claims_cmd)

    ol = sub.add_parser("outline", help="план переплавки", parents=[common])
    ol_sub = ol.add_subparsers(dest="outline_cmd", required=True)
    olv = ol_sub.add_parser("validate", parents=[common], help="проверить план против скелета")
    olv.add_argument("outline", help="JSON-файл плана")
    olv.add_argument("--source", help="исходник: анти-выдумывание карт и чисел")
    olv.add_argument("--game", default="hearthstone")
    olv.add_argument("--profile", choices=P.available())
    olv.set_defaults(func=outline_validate)

    c = sub.add_parser("cards", help="только сверка названий карт", parents=[common])
    c.add_argument("file")
    c.add_argument("--profile", choices=P.available())
    c.set_defaults(func=cards_cmd)

    corp = sub.add_parser("corpus", help="проверки корпуса", parents=[common])
    corp_sub = corp.add_subparsers(dest="corpus_cmd", required=True)
    cv = corp_sub.add_parser("validate", parents=[common])
    cv.set_defaults(func=corpus_validate)
    cs = corp_sub.add_parser(
        "split", parents=[common], help="детерминированное разбиение на калибровку и holdout"
    )
    cs.set_defaults(func=corpus_split)
    ca = corp_sub.add_parser("add", parents=[common], help="добавить candidate или approved guide")
    ca.add_argument("file")
    ca.add_argument("--id")
    ca.add_argument("--published-at", required=True)
    ca.add_argument("--patch", required=True)
    ca.add_argument("--author", default="manacost")
    ca.add_argument("--tag", dest="tags", action="append", default=[])
    ca.add_argument("--source", default="published")
    ca.add_argument("--genre", choices=P.available(), default="constructed-guide")
    ca.add_argument("--approve", action="store_true", help="явное решение человека")
    ca.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    ca.set_defaults(func=corpus_add)
    cap = corp_sub.add_parser("approve", parents=[common], help="активировать candidate")
    cap.add_argument("guide_id")
    cap.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    cap.set_defaults(func=corpus_approve)
    cr = corp_sub.add_parser(
        "remove", parents=[common], help="архивировать guide и пересчитать baseline"
    )
    cr.add_argument("guide_id")
    cr.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    cr.set_defaults(func=corpus_remove)
    crj = corp_sub.add_parser("reject", parents=[common], help="отклонить candidate")
    crj.add_argument("guide_id")
    crj.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    crj.set_defaults(func=corpus_reject)
    crv = corp_sub.add_parser("versions", parents=[common])
    crv.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    crv.set_defaults(func=corpus_versions)
    crb = corp_sub.add_parser("rollback", parents=[common])
    crb.add_argument("version")
    crb.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    crb.set_defaults(func=corpus_rollback)
    ci = corp_sub.add_parser("inspect", parents=[common])
    ci.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    ci.set_defaults(func=corpus_inspect)
    cc = corp_sub.add_parser("compare", parents=[common])
    cc.add_argument("before_version")
    cc.add_argument("after_version")
    cc.add_argument("--collection", choices=CORPUS_COLLECTIONS, default="main")
    cc.set_defaults(func=corpus_compare)
    cib = corp_sub.add_parser(
        "import-bg",
        parents=[common],
        help="импортировать папку TXT о Полях сражений как отдельные candidates",
    )
    cib.add_argument("directory")
    cib.set_defaults(func=corpus_import_bg)
    cig = corp_sub.add_parser(
        "import-guides",
        parents=[common],
        help="импортировать архив обычных TXT-гайдов с PDF/TXT-dedup",
    )
    cig.add_argument("directory")
    cig.set_defaults(func=corpus_import_guides)

    cfg = sub.add_parser("config", help="проверки конфигурации правил", parents=[common])
    cfg_sub = cfg.add_subparsers(dest="config_cmd", required=True)
    cfgv = cfg_sub.add_parser("validate", parents=[common])
    cfgv.set_defaults(func=config_validate)

    pr = sub.add_parser("profiles", help="список жанровых профилей", parents=[common])
    pr.set_defaults(func=profiles_cmd)
    return ap


def _ensure_utf8_stdio() -> None:
    """Вывод в UTF-8: на Windows в трубе stdout получает cp1251 и падает на «→»."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


def main(argv=None) -> int:
    _ensure_utf8_stdio()
    parser = build_parser()
    args = parser.parse_args(argv)
    # флаг мог стоять и до подкоманды, и после — берём то, что задано
    args.format = getattr(args, "format", None) or "text"
    args.fail_on = getattr(args, "fail_on", None) or "error"
    try:
        return args.func(args)
    except ValueError as error:
        if getattr(args, "task_context", None):
            parser.error(str(error))
        raise


if __name__ == "__main__":
    sys.exit(main())
