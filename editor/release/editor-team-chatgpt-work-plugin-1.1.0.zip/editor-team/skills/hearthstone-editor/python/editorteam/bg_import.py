"""Импорт опубликованных TXT-материалов о Полях сражений.

Исходники остаются внешними и неизменными. В corpus-bg попадают только
нормализованные candidate-копии с полной provenance-метаинформацией.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from editorteam.corpus_learning import (
    CorpusError,
    CorpusStore,
    _hash,
    _normalise,
    _split_front_matter,
)

NORMALIZATION_VERSION = 1
PROMO_MARKER = re.compile(r"^наша группа вконтакте\s*,?\s*присоединяйтесь\s*:?$", re.I)
AUTHOR_LINE = re.compile(r"^автор[\s\u00a0]+([^\n.]{2,80})\.?$", re.I | re.M)


@dataclass(frozen=True)
class ParsedGuide:
    source_path: Path
    source_format: str
    title: str
    url: str
    published_at: str
    author: str
    categories: list[str]
    body: str
    source_sha256: str
    source_words: int
    normalized_words: int
    promo_removed: bool


def _metadata(lines: list[str], allowed: set[str]) -> dict[str, str]:
    result = {}
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        if key in allowed:
            result[key] = value.strip()
    return result


def _date(value: str) -> str:
    for pattern in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(value.strip(), pattern).strftime("%Y-%m-%d")
        except ValueError:
            pass
    raise ValueError(f"неизвестный формат даты: {value or 'пусто'}")


def _clean_body(text: str) -> tuple[str, bool]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u00a0", " ").split("\n")
    lines = [line.rstrip() for line in lines]
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    promo_removed = False
    tail_start = max(0, len(lines) - 30)
    for index in range(tail_start, len(lines)):
        if PROMO_MARKER.match(lines[index].strip()):
            lines = lines[:index]
            promo_removed = True
            break
    while lines and not lines[-1].strip():
        lines.pop()
    body = "\n".join(lines).strip()
    body = re.sub(r"\n{3,}", "\n\n", body)
    return body + "\n" if body else "", promo_removed


def _subgenre(title: str) -> str:
    lower = title.lower()
    if re.search(r"\b(топ|рейтинг|лучших|худших|тир[- ]?лист)\b", lower):
        return "ranking"
    if "гайд по" in lower:
        return "hero-or-mechanic-guide"
    if re.search(r"\b(стратег|композиц|стол)\w*\b", lower):
        return "composition-guide"
    return "battlegrounds-article"


def parse_txt(path: Path) -> ParsedGuide:
    source_path = Path(path)
    try:
        raw_bytes = source_path.read_bytes()
        raw = raw_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError("файл должен быть UTF-8") from exc
    except OSError as exc:
        raise ValueError(f"не удалось прочитать файл: {exc}") from exc
    if not raw.strip():
        raise ValueError("пустой файл")

    if "--- TEXT ---" in raw:
        header, body_source = raw.split("--- TEXT ---", 1)
        meta = _metadata(
            header.splitlines(), {"title", "url", "date", "author", "categories"}
        )
        source_format = "manacost-export-v1"
        title = meta.get("title", "").strip()
        date_value = meta.get("date", "")
        author = meta.get("author", "unknown").strip() or "unknown"
        categories = [item.strip() for item in meta.get("categories", "").split(",") if item.strip()]
    else:
        text_heading = re.search(r"(?m)^##\s+Текст\s*$", raw)
        if not text_heading:
            raise ValueError("не найден раздел '--- TEXT ---' или '## Текст'")
        header, body_source = raw[: text_heading.start()], raw[text_heading.end() :]
        meta = _metadata(header.splitlines(), {"id", "url", "дата", "тип", "категория"})
        source_format = "legacy-koloda-export-v1"
        title_match = re.search(r"(?m)^#\s+(.+?)\s*$", header)
        title = title_match.group(1).strip() if title_match else ""
        date_value = meta.get("дата", "")
        categories = [
            value
            for value in (meta.get("тип", "").strip(), meta.get("категория", "").strip())
            if value
        ]
        author_match = AUTHOR_LINE.search(body_source.replace("\u00a0", " "))
        author = author_match.group(1).strip() if author_match else "unknown"

    if not title:
        raise ValueError("не найден заголовок")
    published_at = _date(date_value)
    url = meta.get("url", "").strip()
    parsed_url = urlparse(url)
    if not url or parsed_url.scheme not in {"http", "https"} or not parsed_url.netloc:
        raise ValueError("не найден корректный URL")
    body, promo_removed = _clean_body(body_source)
    if not body.strip():
        raise ValueError("после нормализации не осталось текста")

    return ParsedGuide(
        source_path=source_path,
        source_format=source_format,
        title=unicodedata.normalize("NFC", title),
        url=url,
        published_at=published_at,
        author=unicodedata.normalize("NFC", author),
        categories=[unicodedata.normalize("NFC", item) for item in dict.fromkeys(categories)],
        body=unicodedata.normalize("NFC", body),
        source_sha256=hashlib.sha256(raw_bytes).hexdigest(),
        source_words=len(raw.split()),
        normalized_words=len(body.split()),
        promo_removed=promo_removed,
    )


def _front_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return json.dumps(value, ensure_ascii=False)


def normalized_markdown(guide: ParsedGuide, relative_source: str, guide_id: str) -> str:
    fields = {
        "id": guide_id,
        "title": guide.title,
        "genre": "battlegrounds-guide",
        "subgenre": _subgenre(guide.title),
        "published_at": guide.published_at,
        "patch": "unknown",
        "author": guide.author,
        "source": "published",
        "source_url": guide.url,
        "source_path": relative_source,
        "source_sha256": guide.source_sha256,
        "source_format": guide.source_format,
        "normalization_version": NORMALIZATION_VERSION,
        "historical": True,
        "style_only": True,
        "knowledge_eligible": False,
    }
    front = "\n".join(f"{key}: {_front_value(value)}" for key, value in fields.items())
    body = guide.body
    if not re.match(r"(?m)^#\s+", body):
        body = f"# {guide.title}\n\n{body}"
    return f"---\n{front}\n---\n{body.rstrip()}\n"


def import_directory(source_dir: Path, store: CorpusStore) -> dict:
    root = Path(source_dir).resolve()
    if not root.is_dir():
        raise CorpusError("BG_IMPORT_SOURCE_ERROR", f"нет каталога: {root}")
    files = sorted(root.rglob("*.txt"), key=lambda path: unicodedata.normalize("NFC", str(path)))
    if not files:
        raise CorpusError("BG_IMPORT_EMPTY", f"в каталоге нет TXT-файлов: {root}")

    manifest = store.ensure()
    source_hashes = {
        item.get("source_sha256") for item in manifest.get("guides", []) if item.get("source_sha256")
    }
    normalized_hashes = {
        item.get("normalized_sha256")
        for item in manifest.get("guides", [])
        if item.get("normalized_sha256")
    }
    records = []
    accounting = []
    parsed_guides: list[ParsedGuide] = []
    batch_source_hashes: set[str] = set()
    batch_normalized_hashes: set[str] = set()

    for path in files:
        relative = unicodedata.normalize("NFC", path.relative_to(root).as_posix())
        try:
            guide = parse_txt(path)
            guide_id = f"bg-{guide.published_at}-{_subgenre(guide.title)}-{guide.source_sha256[:10]}"
            content = normalized_markdown(guide, relative, guide_id)
            _, body = _split_front_matter(content)
            normalized_sha = _hash(_normalise(body))
            parsed_guides.append(guide)
            duplicate = (
                guide.source_sha256 in source_hashes
                or guide.source_sha256 in batch_source_hashes
                or normalized_sha in normalized_hashes
                or normalized_sha in batch_normalized_hashes
            )
            if duplicate:
                accounting.append({"file": relative, "status": "duplicate"})
                continue
            batch_source_hashes.add(guide.source_sha256)
            batch_normalized_hashes.add(normalized_sha)
            records.append(
                {
                    "content": content,
                    "source_file": relative,
                    "guide_id": guide_id,
                    "title": guide.title,
                    "published_at": guide.published_at,
                    "patch": "unknown",
                    "author": guide.author,
                    "tags": ["battlegrounds", *guide.categories],
                    "source": "published",
                    "genre": "battlegrounds-guide",
                    "run_quality": False,
                    "extra_meta": {
                        "subgenre": _subgenre(guide.title),
                        "source_url": guide.url,
                        "source_path": relative,
                        "source_sha256": guide.source_sha256,
                        "source_format": guide.source_format,
                        "source_domain": urlparse(guide.url).netloc,
                        "normalization_version": NORMALIZATION_VERSION,
                        "source_words": guide.source_words,
                        "normalized_words": guide.normalized_words,
                        "promo_removed": guide.promo_removed,
                        "historical": True,
                        "knowledge_eligible": False,
                    },
                }
            )
            accounting.append({"file": relative, "status": "ready", "guide_id": guide_id})
        except ValueError as exc:
            accounting.append({"file": relative, "status": "failed", "error": str(exc)})

    if records:
        add_result = store.add_candidates(records)
        imported_ids = {entry["id"] for entry in add_result["entries"]}
        for item in accounting:
            if item.get("status") == "ready" and item.get("guide_id") in imported_ids:
                item["status"] = "imported"
    else:
        add_result = {
            "corpus_version": manifest["current_version"],
            "regression": "NOT_REQUIRED",
            "guides_added": 0,
            "entries": [],
        }

    counts = Counter(item["status"] for item in accounting)
    authors = Counter(guide.author for guide in parsed_guides)
    formats = Counter(guide.source_format for guide in parsed_guides)
    dates = sorted(guide.published_at for guide in parsed_guides)
    total_accounted = sum(counts[name] for name in ("imported", "duplicate", "failed", "skipped"))
    return {
        "source_directory": str(root),
        "collection": store.relative_dir,
        "corpus_version": add_result["corpus_version"],
        "discovered": len(files),
        "imported": counts["imported"],
        "duplicates": counts["duplicate"],
        "failed": counts["failed"],
        "skipped": counts["skipped"],
        "accounted": total_accounted,
        "accounting_valid": total_accounted == len(files),
        "source_words": sum(guide.source_words for guide in parsed_guides),
        "normalized_words": sum(guide.normalized_words for guide in parsed_guides),
        "promo_blocks_removed": sum(guide.promo_removed for guide in parsed_guides),
        "authors": dict(sorted(authors.items())),
        "formats": dict(sorted(formats.items())),
        "date_range": [dates[0], dates[-1]] if dates else [None, None],
        "historical": True,
        "knowledge_eligible": False,
        "files": accounting,
    }
