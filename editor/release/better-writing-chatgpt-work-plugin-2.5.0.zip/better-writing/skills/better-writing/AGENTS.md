# better-writing

Canonical behaviour lives in `SKILL.md`.

Use this general-purpose skill to draft, rewrite, line edit, review, humanise, adapt, or synthesise English and Russian prose while preserving source truth, provenance, exact literals, uncertainty, and writer identity. Choose the narrowest useful intervention and honour clean, annotated, review-only, or side-by-side delivery. For PDFs, scans, OCR output, or large document collections, load `references/pdf-and-large-corpora.md`, inventory every file, keep page-level provenance, work in bounded chunks, and disclose extraction failures instead of filling gaps. Run the full formulaic-language pass only when humanisation or genericity is actually in scope. For Russian prose, load `references/russian-profile.md` and do not use the English scanner as a release gate. Treat every diagnostic match as a revision prompt, never evidence of authorship.
