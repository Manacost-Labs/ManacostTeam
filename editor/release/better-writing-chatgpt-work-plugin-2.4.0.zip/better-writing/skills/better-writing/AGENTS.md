# better-writing

Canonical behaviour lives in `SKILL.md`.

Use this general-purpose skill to draft, rewrite, line edit, review, humanise, or adapt English and Russian prose while preserving source truth, exact literals, uncertainty, and writer identity. Choose the narrowest useful intervention and honour clean, annotated, review-only, or side-by-side delivery. Run the full formulaic-language pass only when humanisation or genericity is actually in scope. For Russian prose, load `references/russian-profile.md` and do not use the English scanner as a release gate. Treat every diagnostic match as a revision prompt, never evidence of authorship.
